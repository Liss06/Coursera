import { Component } from '@angular/core';

@Component({
  selector: 'app-vuelos-component',
  templateUrl: './vuelos-component.component.html',
  styleUrls: ['./vuelos-component.component.css']
})
export class VuelosComponent {

}
